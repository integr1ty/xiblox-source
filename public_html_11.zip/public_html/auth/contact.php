<?php
  include("../SiT_3/reliveheader.php");
  //if($loggedIn) {header("Location: /dashboard"); die();}
    ?>
<title>Contact - <?php echo $sitename; ?></title>
<div class="container mt-4">
    <div class="row">
        <div class="col-12 col-lg-6 offset-lg-3">
            <h1>Contact</h1>
            <p>All inquires should be sent through email: <span class="fw-bold">goodhillofficial@gmail.com</span></p>
            <p>You may send questions regarding password resets or account recovery. This is because we do not have a password reset page.</p>
            <br>
            <p>Not everything can be fixed using support, however we will try our best to deal with any problems you may have.</p>
        </div>
    </div>
</div>
</main>
                          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
                          <?php include("../SiT_3/relivefooter.php");