<?php 
include("../SiT_3/header.php");
?>
<div id="body">
	<div id="box">
		<div style="width: 49%;float:left;padding: 5px;text-align:center;box-sizing: border-box;">
			Tree
			<br>
			<img src="http://i.imgur.com/GQAYuwn.png" style="width:20%;"/>
		</div>
		<div style="width: 49%;float:left;box-sizing: border-box;padding: 5px;">
			<textarea style="width: 100%;padding: 5px;height:120px;">=" 0 10 5 2 2 6 5384469 1 1
=" 0 10 11 7 7 1 3825419 1 1
=" 0 10 12 6 6 1 3825419 1 1
=" 0 10 13 5 5 1 3825419 1 1
=" 0 10 14 4 4 1 3825419 1 1
=" 0 10 15 3 3 1 3825419 1 1
=" 0 10 16 2 2 1 3825419 1 1
=" 0 10 17 1 1 1 3825419 1 1</textarea>
		</div>
	</div>
</div>
<?php 
include("../SiT_3/footer.php");
?>