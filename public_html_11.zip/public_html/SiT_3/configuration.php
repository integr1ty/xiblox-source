<?php ob_start();
    
    
    include("config.php");
    
    
    $offline = false;
    $sitename = "XIBLOX";
    $sitelink = "https://xiblox.com";
    
?>


