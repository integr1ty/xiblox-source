
<div class="catalogcontainer">
    <div class="leftside">
<h4 style="font-size: 22px; background-color: rgb(200, 200, 200)">Category</h4>
      <ul>
 
          <div class="btn-group btn-group-justified">
          <div class="shop-categories">
<li id="hat" onclick="getPage('hat','','0');">Hats</li>

<li id="hat" onclick="getPage('','','0');">Heads</li>

<li id="hat" onclick="getPage('face','','0');">Faces</li>
            <li id="hat" onclick="getPage('','','0');">Gears</li>
<li id="hat" onclick="getPage('shirt','','0');">Shirts</li>
<li id="hat" onclick="getPage('pants','','0');">Pants</li>

      </ul>
    </div>
    <div class="rightside">
