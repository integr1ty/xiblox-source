<?php
  include("../SiT_3/config.php");
  include("../SiT_3/header.php");
  
  
  if(isset($_GET['search'])) {
    $searchQ = htmlentities($_GET['search']);
  } else {
    $searchQ = '';
  }
?>

<!DOCTYPE html>
  <head>
    <title>Shop - <?php echo $sitename; ?></title>
  </head>
  <body>
<?php
include('shopheader.php');
?>
<div id="crate">
</div>
<script>
    $(window).scroll(debouncer(function() {
        if($(window).scrollTop() + $(window).height() >= $(document).height() - 100 && !shopEnd) {
            loadItems($('.shop-categories .active a').data('itemType'), $('#shopSort :selected').data('sort'), currentSearch, shopPage + 1)
        }
    }));

    loadItems()
</script>

    
<script>
  
  window.onload = function() {
      getPage('all','',0);
    };
  
    function getPage(type, search, page) {
      $("#crate").load("/shop/crate?item="+type+"&search="+search+"&page="+page);
    };
</script>
    </div>
   
  </body>
<html>