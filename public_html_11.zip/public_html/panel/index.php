<?php
  include("../SiT_3/configuration.php");
  include("adminheader.php");
 if($power < 1) {header("Location: ../");die();}
  ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin - <?php echo $sitename; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="container">
<div class="row">
<div class="col-4">
<h3>Admin</h3>
</div>
<div class="col-8 text-right">
</div>
</div>
<ul class="breadcrumb bg-white">
<li class="breadcrumb-item"><a href="/">Admin</a></li>
<li class="breadcrumb-item active">Home</li>
</ul>
<div class="row">
<div class="col-6 col-md-3 text-center">
<a href="manage-users" style="color:#28a745;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-user mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Users</div>
</div>
</div>
</a>
</div>
<div class="col-6 col-md-3 text-center">
<a href="manage-economy" style="color:#28a745;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fa fa-money mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Manage Economy</div>
</div>
</div>
</a>
</div>
<div class="col-6 col-md-3 text-center">
<a href="/reports" style="color:#ffc107;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-flag mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Pending Reports</div>
</div>
  </div>
  </a>
  </div>
  <div class="col-6 col-md-3 text-center">
<a href="asset-approval" style="color:#ffc107;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-image mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Pending Assets</div>
</div>
</div>
</a>
</div>
  <div class="col-6 col-md-3 text-center">
<a href="create/hat" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-hat-cowboy mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create Hat</div>
</div>
</div>
</a>
</div>
  <div class="col-6 col-md-3 text-center">
<a href="create/face" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-smile mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create Face</div>
</div>
</div>
</a>
</div>
  <div class="col-6 col-md-3 text-center">
<a href="create/gadget" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-hammer mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create Gadget</div>
</div>
</div>
</a>
</div>
  <div class="col-6 col-md-3 text-center">
<a href="create/head" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-smile mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create Head</div>
</div>
</div>
</a>
</div>
    <div class="col-6 col-md-3 text-center">
<a href="site-settings" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-cog mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Site Settings</div>
</div>
</div>
</a>
</div>
  <div class="col-6 col-md-3 text-center">
<a href="create-blog" style="color:#0082ff;text-decoration:none;">
<div class="card">
<div class="card-body">
<i class="fas fa-newspaper mb-2" style="font-size:60px;"></i>
<div class="text-truncate" style="font-weight:600;">Create Blog Post</div>
</div>
</div>
</a>
</div>
  </div>
<?php
  include("../SiT_3/footer.php");
    ?>